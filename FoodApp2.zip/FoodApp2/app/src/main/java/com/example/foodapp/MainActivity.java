package com.example.foodapp;

import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Filter ;
import android.Request;
import android.Product;
import android.Shop;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText categoryEdit, starsEdit, priceEdit;
    private Button submitButton;
    private Handler handler;
    private final String Latitude = "37.9897";
    private final String Longitude = "23.7260";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categoryEdit = findViewById(R.id.categoryEdit);
        starsEdit = findViewById(R.id.starsEdit);
        priceEdit = findViewById(R.id.priceEdit);
        submitButton = findViewById(R.id.submitButton);

        handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                if (msg.what == 1) {
                    ArrayList<Shop> shopList = (ArrayList<Shop>) msg.obj;
                    Intent intent = new Intent(MainActivity.this, ShopListActivity.class);
                    intent.putExtra("shopList", shopList);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_LONG).show();
                }
            }
        };

        submitButton.setOnClickListener(v -> {
            String category = categoryEdit.getText().toString();
            String stars = starsEdit.getText().toString();
            String price = priceEdit.getText().toString();

            Filter filter = new Filter(category, stars, price, Latitude, Longitude, 1);
            new SocketThread("Filter", filter, null, handler).start();
        });
    }
}