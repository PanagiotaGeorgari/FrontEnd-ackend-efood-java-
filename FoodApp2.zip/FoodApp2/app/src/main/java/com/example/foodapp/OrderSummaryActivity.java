package com.example.foodapp;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Order;
import android.annotation.SuppressLint;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.Filter ;
import android.Request;
import android.Product;
import android.Shop;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
public class OrderSummaryActivity extends AppCompatActivity {

    private TextView orderDetailsTextView;
    private Button confirmOrderButton;
    private Order order;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);

        order = (Order) getIntent().getSerializableExtra("order");

        orderDetailsTextView = findViewById(R.id.detailstextview);
        confirmOrderButton = findViewById(R.id.confirmOrderButton);

        displayOrderDetails();

        confirmOrderButton.setOnClickListener(v -> {
            if (order != null) {
                new SocketThread("Order", null, order, new Handler(Looper.getMainLooper()) {
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        if (msg.what == 1) {
                            Toast.makeText(OrderSummaryActivity.this, "Παραγγελία ολοκληρώθηκε με επιτυχία", Toast.LENGTH_LONG).show();
                            finish(); // Να επιστρέψουμε στην προηγούμενη οθόνη ή στο αρχικό Activity
                        } else {
                            Toast.makeText(OrderSummaryActivity.this, "Σφάλμα στην αποστολή της παραγγελίας: " + msg.obj, Toast.LENGTH_LONG).show();
                        }
                    }
                }).start();
            }
        });
    }

    private void displayOrderDetails() {
        StringBuilder orderDetails = new StringBuilder();
        for (Map.Entry<Product, Integer> entry : order.getOrder_items().entrySet()) {
            Product product = entry.getKey();
            Integer quantity = entry.getValue();
            orderDetails.append("Προϊόν: ").append(product.getProductName())
                    .append("\nΠοσότητα: ").append(quantity)
                    .append("\nΤιμή: ").append(product.getPrice() * quantity)
                    .append("€\n\n");
        }

        orderDetailsTextView.setText(orderDetails.toString());
    }
}