package com.example.foodapp;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Order;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Filter ;
import android.Request;
import android.Product;
import android.Shop;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class ProductSelectionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button confirmOrderButton;
    private Shop selectedShop;
    private HashMap<Product, Integer> selectedProducts = new HashMap<>(); // προϊόν -> ποσότητα

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_selection);

        selectedShop = (Shop) getIntent().getSerializableExtra("selectedShop");

        recyclerView = findViewById(R.id.productRecyclerView);
        confirmOrderButton = findViewById(R.id.confirmOrderButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ProductAdapter(selectedShop.getProducts(), selectedProducts));

        confirmOrderButton.setOnClickListener(v -> {
            if (selectedProducts.isEmpty()) {
                Toast.makeText(this, "Δεν έχετε επιλέξει προϊόντα", Toast.LENGTH_SHORT).show();
                return;
            }

            Order order = new Order(selectedShop.getShopName(), selectedProducts,
                    selectedShop.getFoodCategory(), selectedShop);

            Intent intent = new Intent(ProductSelectionActivity.this, OrderSummaryActivity.class);
            intent.putExtra("order", order);
            startActivity(intent);
        });
    }
}